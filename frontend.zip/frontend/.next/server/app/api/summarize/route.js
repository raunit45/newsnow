/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/summarize/route";
exports.ids = ["app/api/summarize/route"];
exports.modules = {

/***/ "(rsc)/./app/api/summarize/route.ts":
/*!************************************!*\
  !*** ./app/api/summarize/route.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\nasync function POST(request) {\n    try {\n        const { title, description } = await request.json();\n        const apiKey = process.env.GEMINI_API_KEY;\n        if (!apiKey) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                error: \"Missing GEMINI_API_KEY\"\n            }, {\n                status: 500\n            });\n        }\n        const prompt = `Summarize in 2-3 sentences. Then provide two percentages that sum to 100 for how true vs false this seems. Output strictly in JSON with keys: summary, truthPercent, falsePercent. Title: \"${title}\". Description: ${description}`;\n        const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {\n            method: \"POST\",\n            headers: {\n                \"Content-Type\": \"application/json\"\n            },\n            body: JSON.stringify({\n                contents: [\n                    {\n                        parts: [\n                            {\n                                text: prompt\n                            }\n                        ]\n                    }\n                ]\n            })\n        });\n        const data = await resp.json();\n        const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;\n        if (!text) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                error: \"No content from model\"\n            }, {\n                status: 502\n            });\n        }\n        let summary = \"\";\n        let truthPercent = 0;\n        let falsePercent = 0;\n        try {\n            const parsed = JSON.parse(text);\n            summary = parsed.summary || \"\";\n            truthPercent = Number(parsed.truthPercent) || 0;\n            falsePercent = Number(parsed.falsePercent) || Math.max(0, 100 - truthPercent);\n        } catch  {\n            // Fallback: parse percentages from free-form text\n            summary = text.replace(/\\n/g, \" \").slice(0, 600);\n            const matches = (text.match(/(\\d{1,3})%/g) || []).map((m)=>parseInt(m, 10));\n            if (matches.length >= 2) {\n                truthPercent = Math.min(100, Math.max(matches[0], matches[1]));\n                falsePercent = 100 - truthPercent;\n            }\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            summary,\n            truthPercent,\n            falsePercent\n        });\n    } catch (err) {\n        console.error(\"Summarize API error\", err);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            error: \"Internal server error\"\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL3N1bW1hcml6ZS9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7OztBQUE0RDtBQUVyRCxlQUFlQyxLQUFLQyxPQUFvQjtJQUM3QyxJQUFJO1FBQ0YsTUFBTSxFQUFFQyxLQUFLLEVBQUVDLFdBQVcsRUFBRSxHQUFHLE1BQU1GLFFBQVFHLElBQUk7UUFDakQsTUFBTUMsU0FBU0MsUUFBUUMsR0FBRyxDQUFDQyxjQUFjO1FBQ3pDLElBQUksQ0FBQ0gsUUFBUTtZQUNYLE9BQU9OLHFEQUFZQSxDQUFDSyxJQUFJLENBQUM7Z0JBQUVLLE9BQU87WUFBeUIsR0FBRztnQkFBRUMsUUFBUTtZQUFJO1FBQzlFO1FBRUEsTUFBTUMsU0FBUyxDQUFDLDJMQUEyTCxFQUFFVCxNQUFNLGdCQUFnQixFQUFFQyxhQUFhO1FBRWxQLE1BQU1TLE9BQU8sTUFBTUMsTUFDakIsQ0FBQyx1RkFBdUYsRUFBRVIsUUFBUSxFQUNsRztZQUNFUyxRQUFRO1lBQ1JDLFNBQVM7Z0JBQUUsZ0JBQWdCO1lBQW1CO1lBQzlDQyxNQUFNQyxLQUFLQyxTQUFTLENBQUM7Z0JBQUVDLFVBQVU7b0JBQUM7d0JBQUVDLE9BQU87NEJBQUM7Z0NBQUVDLE1BQU1WOzRCQUFPO3lCQUFFO29CQUFDO2lCQUFFO1lBQUM7UUFDbkU7UUFHRixNQUFNVyxPQUFPLE1BQU1WLEtBQUtSLElBQUk7UUFDNUIsTUFBTWlCLE9BQU9DLE1BQU1DLFlBQVksQ0FBQyxFQUFFLEVBQUVDLFNBQVNKLE9BQU8sQ0FBQyxFQUFFLEVBQUVDO1FBQ3pELElBQUksQ0FBQ0EsTUFBTTtZQUNULE9BQU90QixxREFBWUEsQ0FBQ0ssSUFBSSxDQUFDO2dCQUFFSyxPQUFPO1lBQXdCLEdBQUc7Z0JBQUVDLFFBQVE7WUFBSTtRQUM3RTtRQUVBLElBQUllLFVBQVU7UUFDZCxJQUFJQyxlQUFlO1FBQ25CLElBQUlDLGVBQWU7UUFFbkIsSUFBSTtZQUNGLE1BQU1DLFNBQVNYLEtBQUtZLEtBQUssQ0FBQ1I7WUFDMUJJLFVBQVVHLE9BQU9ILE9BQU8sSUFBSTtZQUM1QkMsZUFBZUksT0FBT0YsT0FBT0YsWUFBWSxLQUFLO1lBQzlDQyxlQUFlRyxPQUFPRixPQUFPRCxZQUFZLEtBQUtJLEtBQUtDLEdBQUcsQ0FBQyxHQUFHLE1BQU1OO1FBQ2xFLEVBQUUsT0FBTTtZQUNOLGtEQUFrRDtZQUNsREQsVUFBVUosS0FBS1ksT0FBTyxDQUFDLE9BQU8sS0FBS0MsS0FBSyxDQUFDLEdBQUc7WUFDNUMsTUFBTUMsVUFBVSxDQUFDZCxLQUFLZSxLQUFLLENBQUMsa0JBQWtCLEVBQUUsRUFBRUMsR0FBRyxDQUFDLENBQUNDLElBQU1DLFNBQVNELEdBQUc7WUFDekUsSUFBSUgsUUFBUUssTUFBTSxJQUFJLEdBQUc7Z0JBQ3ZCZCxlQUFlSyxLQUFLVSxHQUFHLENBQUMsS0FBS1YsS0FBS0MsR0FBRyxDQUFDRyxPQUFPLENBQUMsRUFBRSxFQUFFQSxPQUFPLENBQUMsRUFBRTtnQkFDNURSLGVBQWUsTUFBTUQ7WUFDdkI7UUFDRjtRQUVBLE9BQU8zQixxREFBWUEsQ0FBQ0ssSUFBSSxDQUFDO1lBQUVxQjtZQUFTQztZQUFjQztRQUFhO0lBQ2pFLEVBQUUsT0FBT2UsS0FBSztRQUNaQyxRQUFRbEMsS0FBSyxDQUFDLHVCQUF1QmlDO1FBQ3JDLE9BQU8zQyxxREFBWUEsQ0FBQ0ssSUFBSSxDQUFDO1lBQUVLLE9BQU87UUFBd0IsR0FBRztZQUFFQyxRQUFRO1FBQUk7SUFDN0U7QUFDRiIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxyYXVuaVxcRG93bmxvYWRzXFxuZXdzbm93XFxhcHBcXGFwaVxcc3VtbWFyaXplXFxyb3V0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZXh0UmVzcG9uc2UsIHR5cGUgTmV4dFJlcXVlc3QgfSBmcm9tIFwibmV4dC9zZXJ2ZXJcIlxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIFBPU1QocmVxdWVzdDogTmV4dFJlcXVlc3QpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgeyB0aXRsZSwgZGVzY3JpcHRpb24gfSA9IGF3YWl0IHJlcXVlc3QuanNvbigpXHJcbiAgICBjb25zdCBhcGlLZXkgPSBwcm9jZXNzLmVudi5HRU1JTklfQVBJX0tFWVxyXG4gICAgaWYgKCFhcGlLZXkpIHtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgZXJyb3I6IFwiTWlzc2luZyBHRU1JTklfQVBJX0tFWVwiIH0sIHsgc3RhdHVzOiA1MDAgfSlcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBwcm9tcHQgPSBgU3VtbWFyaXplIGluIDItMyBzZW50ZW5jZXMuIFRoZW4gcHJvdmlkZSB0d28gcGVyY2VudGFnZXMgdGhhdCBzdW0gdG8gMTAwIGZvciBob3cgdHJ1ZSB2cyBmYWxzZSB0aGlzIHNlZW1zLiBPdXRwdXQgc3RyaWN0bHkgaW4gSlNPTiB3aXRoIGtleXM6IHN1bW1hcnksIHRydXRoUGVyY2VudCwgZmFsc2VQZXJjZW50LiBUaXRsZTogXCIke3RpdGxlfVwiLiBEZXNjcmlwdGlvbjogJHtkZXNjcmlwdGlvbn1gXHJcblxyXG4gICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKFxyXG4gICAgICBgaHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL21vZGVscy9nZW1pbmktcHJvOmdlbmVyYXRlQ29udGVudD9rZXk9JHthcGlLZXl9YCxcclxuICAgICAge1xyXG4gICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgY29udGVudHM6IFt7IHBhcnRzOiBbeyB0ZXh0OiBwcm9tcHQgfV0gfV0gfSksXHJcbiAgICAgIH0sXHJcbiAgICApXHJcblxyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3AuanNvbigpXHJcbiAgICBjb25zdCB0ZXh0ID0gZGF0YT8uY2FuZGlkYXRlcz8uWzBdPy5jb250ZW50Py5wYXJ0cz8uWzBdPy50ZXh0IGFzIHN0cmluZyB8IHVuZGVmaW5lZFxyXG4gICAgaWYgKCF0ZXh0KSB7XHJcbiAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IGVycm9yOiBcIk5vIGNvbnRlbnQgZnJvbSBtb2RlbFwiIH0sIHsgc3RhdHVzOiA1MDIgfSlcclxuICAgIH1cclxuXHJcbiAgICBsZXQgc3VtbWFyeSA9IFwiXCJcclxuICAgIGxldCB0cnV0aFBlcmNlbnQgPSAwXHJcbiAgICBsZXQgZmFsc2VQZXJjZW50ID0gMFxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dClcclxuICAgICAgc3VtbWFyeSA9IHBhcnNlZC5zdW1tYXJ5IHx8IFwiXCJcclxuICAgICAgdHJ1dGhQZXJjZW50ID0gTnVtYmVyKHBhcnNlZC50cnV0aFBlcmNlbnQpIHx8IDBcclxuICAgICAgZmFsc2VQZXJjZW50ID0gTnVtYmVyKHBhcnNlZC5mYWxzZVBlcmNlbnQpIHx8IE1hdGgubWF4KDAsIDEwMCAtIHRydXRoUGVyY2VudClcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBGYWxsYmFjazogcGFyc2UgcGVyY2VudGFnZXMgZnJvbSBmcmVlLWZvcm0gdGV4dFxyXG4gICAgICBzdW1tYXJ5ID0gdGV4dC5yZXBsYWNlKC9cXG4vZywgXCIgXCIpLnNsaWNlKDAsIDYwMClcclxuICAgICAgY29uc3QgbWF0Y2hlcyA9ICh0ZXh0Lm1hdGNoKC8oXFxkezEsM30pJS9nKSB8fCBbXSkubWFwKChtKSA9PiBwYXJzZUludChtLCAxMCkpXHJcbiAgICAgIGlmIChtYXRjaGVzLmxlbmd0aCA+PSAyKSB7XHJcbiAgICAgICAgdHJ1dGhQZXJjZW50ID0gTWF0aC5taW4oMTAwLCBNYXRoLm1heChtYXRjaGVzWzBdLCBtYXRjaGVzWzFdKSlcclxuICAgICAgICBmYWxzZVBlcmNlbnQgPSAxMDAgLSB0cnV0aFBlcmNlbnRcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1bW1hcnksIHRydXRoUGVyY2VudCwgZmFsc2VQZXJjZW50IH0pXHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiU3VtbWFyaXplIEFQSSBlcnJvclwiLCBlcnIpXHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogXCJJbnRlcm5hbCBzZXJ2ZXIgZXJyb3JcIiB9LCB7IHN0YXR1czogNTAwIH0pXHJcbiAgfVxyXG59XHJcblxyXG5cclxuIl0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsIlBPU1QiLCJyZXF1ZXN0IiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImpzb24iLCJhcGlLZXkiLCJwcm9jZXNzIiwiZW52IiwiR0VNSU5JX0FQSV9LRVkiLCJlcnJvciIsInN0YXR1cyIsInByb21wdCIsInJlc3AiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnRzIiwicGFydHMiLCJ0ZXh0IiwiZGF0YSIsImNhbmRpZGF0ZXMiLCJjb250ZW50Iiwic3VtbWFyeSIsInRydXRoUGVyY2VudCIsImZhbHNlUGVyY2VudCIsInBhcnNlZCIsInBhcnNlIiwiTnVtYmVyIiwiTWF0aCIsIm1heCIsInJlcGxhY2UiLCJzbGljZSIsIm1hdGNoZXMiLCJtYXRjaCIsIm1hcCIsIm0iLCJwYXJzZUludCIsImxlbmd0aCIsIm1pbiIsImVyciIsImNvbnNvbGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/summarize/route.ts\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fsummarize%2Froute&page=%2Fapi%2Fsummarize%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fsummarize%2Froute.ts&appDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fsummarize%2Froute&page=%2Fapi%2Fsummarize%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fsummarize%2Froute.ts&appDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_rauni_Downloads_newsnow_app_api_summarize_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/summarize/route.ts */ \"(rsc)/./app/api/summarize/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/summarize/route\",\n        pathname: \"/api/summarize\",\n        filename: \"route\",\n        bundlePath: \"app/api/summarize/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\rauni\\\\Downloads\\\\newsnow\\\\app\\\\api\\\\summarize\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_rauni_Downloads_newsnow_app_api_summarize_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZzdW1tYXJpemUlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRnN1bW1hcml6ZSUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRnN1bW1hcml6ZSUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNyYXVuaSU1Q0Rvd25sb2FkcyU1Q25ld3Nub3clNUNhcHAmcGFnZUV4dGVuc2lvbnM9dHN4JnBhZ2VFeHRlbnNpb25zPXRzJnBhZ2VFeHRlbnNpb25zPWpzeCZwYWdlRXh0ZW5zaW9ucz1qcyZyb290RGlyPUMlM0ElNUNVc2VycyU1Q3JhdW5pJTVDRG93bmxvYWRzJTVDbmV3c25vdyZpc0Rldj10cnVlJnRzY29uZmlnUGF0aD10c2NvbmZpZy5qc29uJmJhc2VQYXRoPSZhc3NldFByZWZpeD0mbmV4dENvbmZpZ091dHB1dD0mcHJlZmVycmVkUmVnaW9uPSZtaWRkbGV3YXJlQ29uZmlnPWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBK0Y7QUFDdkM7QUFDcUI7QUFDbUI7QUFDaEc7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlHQUFtQjtBQUMzQztBQUNBLGNBQWMsa0VBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSxzREFBc0Q7QUFDOUQ7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDMEY7O0FBRTFGIiwic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwUm91dGVSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkM6XFxcXFVzZXJzXFxcXHJhdW5pXFxcXERvd25sb2Fkc1xcXFxuZXdzbm93XFxcXGFwcFxcXFxhcGlcXFxcc3VtbWFyaXplXFxcXHJvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9zdW1tYXJpemUvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9zdW1tYXJpemVcIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL3N1bW1hcml6ZS9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkM6XFxcXFVzZXJzXFxcXHJhdW5pXFxcXERvd25sb2Fkc1xcXFxuZXdzbm93XFxcXGFwcFxcXFxhcGlcXFxcc3VtbWFyaXplXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fsummarize%2Froute&page=%2Fapi%2Fsummarize%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fsummarize%2Froute.ts&appDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fsummarize%2Froute&page=%2Fapi%2Fsummarize%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fsummarize%2Froute.ts&appDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Crauni%5CDownloads%5Cnewsnow&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();